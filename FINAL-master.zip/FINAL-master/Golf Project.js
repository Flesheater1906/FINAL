var numplayers = 1; 
var numholes = 18;
var teetime = 45;
var seconds = 59;
var golflist;
var golfCourse = {};
function addPlayer() {
    numplayers += 1;
    buildcard()
}
function removePlayer() {
    numplayers -= 1;
    buildcard()
}
    beginTimer();
function buildcard(){
    console.log(golfCourse);
    var holecollection = "";
    var playercollection = "";
    var formcollection = "";
    var scoreinfo = "";
    var allcollection = "";
    var incolleciton = "";
    var outcollection = "";
    // create column of player labels
    for(var pl = 1; pl <= numplayers; pl++ ){
        playercollection += "<input id='player" + pl +"' class='playerbox' placeholder='Player " + pl +"'>";
        allcollection += "<div class='holebox'><input type='text' class='scores' disabled='true' id='player" + pl +"all'></div>";
        incolleciton += "<div class='holebox'><input type='text' class='scores' disabled='true' id='player" + pl +"in'></div>";
        outcollection += "<div class='holebox'><input type='text' class='scores' disabled='true' id='player" + pl +"out'></div>";
    }

    // create golf hole columns before you add holes to them.
    for(var c = golfCourse.course.holes.length; c >= 1; c-- ){
        holecollection += "<div id='column" + c +"' class='holecol'><div class='holenumbertitle'>" + c + "<div>PAR<div>" + golfCourse.course.holes[c - 1].tee_boxes[0].par + "</div><div>YARDS<div>" + golfCourse.course.holes[c - 1].tee_boxes[0].yards + "</div></div></div></div></div>";
    }

    scoreinfo += "<input value='0' id='P"+ pl + "Results1' name='P1Results1' type='text' disabled='disabled'>";
    $("#leftcard").html(playercollection);
    $("#rightcard").html('<div class="holecol">All<div><br><div><br></div><div><br><div><br></div></div></div>' + allcollection + '</div><div class="holecol">Out<div><br><div><br></div><div><br><div><br></div></div></div>' + outcollection + '</div><div class="holecol">In<div><br><div><br></div><div><br><div><br></div></div></div>' + incolleciton + '</div>' + holecollection);

    // call the function that builds the holes into the columns
    formcollection += buildholes() + " + " + buildholes2() +"<div class='holecol'></div>";
    $("#column").html(formcollection);
    $("#scores").html(scoreinfo);
}

function buildholes() {
    // add 18 holes to the columns
    for(var p = 1; p <= numplayers; p++ ){
        for(var h = 1; h <= 9; h++){
            $("#column" + h).append("<div id='p"+ p +"h"+ h +"' class='holebox'><input class='scores' value='0' min='-5' max='10' type='number' name='p"+ p +"holea' name='p"+ p +"hole' oninput='score"+ p +"()'></div>");
        }
    }
}
function buildholes2() {
    // add 18 holes to the columns
    for(var p = 1; p <= numplayers; p++ ){
        for(var h = 10; h <= 18; h++){
            $("#column" + h).append("<div id='p"+ p +"h"+ h +"' class='holebox'><input class='scores' value='0' min='-5' max='10' type='number' name='p"+ p +"holeb' name='p"+ p +"hole' oninput='score"+ p +"()'></div>");
        }
    }
}
function score1(){
    var arr1 = document.getElementsByName("p1holea");
    var tot1=0;
    for(var i=0;i<arr1.length;i++){
        if(parseInt(arr1[i].value))
            tot1 += parseInt(arr1[i].value);
    }
    document.getElementById('player1in').value = tot1;
    var arr2 = document.getElementsByName("p1holeb");
    var tot2=0;
    for(var i=0;i<arr2.length;i++){
        if(parseInt(arr2[i].value))
            tot2 += parseInt(arr2[i].value);
    }
    document.getElementById('player1out').value = tot2;
    var abc = document.getElementById('player1in').value;
    var abcd = document.getElementById('player1out').value;
    document.getElementById('player1all').value = +abc + +abcd;
}
function score2(){
    var arr1 = document.getElementsByName("p2holea");
    var tot1=0;
    for(var i=0;i<arr1.length;i++){
        if(parseInt(arr1[i].value))
            tot1 += parseInt(arr1[i].value);
    }
    document.getElementById('player2in').value = tot1;
    var arr2 = document.getElementsByName("p2holeb");
    var tot2=0;
    for(var i=0;i<arr2.length;i++){
        if(parseInt(arr2[i].value))
            tot2 += parseInt(arr2[i].value);
    }
    document.getElementById('player2out').value = tot2;
    var abc = document.getElementById('player2in').value;
    var abcd = document.getElementById('player2out').value;
    document.getElementById('player2all').value = +abc + +abcd;
}
function score3(){
    var arr1 = document.getElementsByName("p3holea");
    var tot1=0;
    for(var i=0;i<arr1.length;i++){
        if(parseInt(arr1[i].value))
            tot1 += parseInt(arr1[i].value);
    }
    document.getElementById('player3in').value = tot1;
    var arr2 = document.getElementsByName("p3holeb");
    var tot2=0;
    for(var i=0;i<arr2.length;i++){
        if(parseInt(arr2[i].value))
            tot2 += parseInt(arr2[i].value);
    }
    document.getElementById('player3out').value = tot2;
    var abc = document.getElementById('player3in').value;
    var abcd = document.getElementById('player3out').value;
    document.getElementById('player3all').value = +abc + +abcd;
}
function score4(){
    var arr1 = document.getElementsByName("p4holea");
    var tot1=0;
    for(var i=0;i<arr1.length;i++){
        if(parseInt(arr1[i].value))
            tot1 += parseInt(arr1[i].value);
    }
    document.getElementById('player4in').value = tot1;
    var arr2 = document.getElementsByName("p4holeb");
    var tot2=0;
    for(var i=0;i<arr2.length;i++){
        if(parseInt(arr2[i].value))
            tot2 += parseInt(arr2[i].value);
    }
    document.getElementById('player4out').value = tot2;
    var abc = document.getElementById('player4in').value;
    var abcd = document.getElementById('player4out').value;
    document.getElementById('player4all').value = +abc + +abcd;
}
function score5(){
    var arr1 = document.getElementsByName("p5holea");
    var tot1=0;
    for(var i=0;i<arr1.length;i++){
        if(parseInt(arr1[i].value))
            tot1 += parseInt(arr1[i].value);
    }
    document.getElementById('player5in').value = tot1;
    var arr2 = document.getElementsByName("p5holeb");
    var tot2=0;
    for(var i=0;i<arr2.length;i++){
        if(parseInt(arr2[i].value))
            tot2 += parseInt(arr2[i].value);
    }
    document.getElementById('player5out').value = tot2;
    var abc = document.getElementById('player5in').value;
    var abcd = document.getElementById('player5out').value;
    document.getElementById('player5all').value = +abc + +abcd;
}
function score6(){
    var arr1 = document.getElementsByName("p6holea");
    var tot1=0;
    for(var i=0;i<arr1.length;i++){
        if(parseInt(arr1[i].value))
            tot1 += parseInt(arr1[i].value);
    }
    document.getElementById('player6in').value = tot1;
    var arr2 = document.getElementsByName("p6holeb");
    var tot2=0;
    for(var i=0;i<arr2.length;i++){
        if(parseInt(arr2[i].value))
            tot2 += parseInt(arr2[i].value);
    }
    document.getElementById('player6out').value = tot2;
    var abc = document.getElementById('player6in').value;
    var abcd = document.getElementById('player6out').value;
    document.getElementById('player6all').value = +abc + +abcd;
}
function beginTimer(){
    var thetimer = setInterval(function(){clocktick()}, 1000);
}

function clocktick(){
    if(seconds > 0){
        seconds --;
        if(seconds < 10){
            seconds = "0" + seconds;
        }
    }
    else{
        teetime --;
        seconds = 59;
    }
    document.getElementById("countdown").innerHTML = teetime + ":" + seconds;
}
function int_zero(x)
{
    if ( x < 1 )
        return 0 ;
    else
        return parseInt( x ,10 );
}
//setcourse.info();
// function setcourseinfo() {
//     buildcard(teeboxid)
// }
function populateList(city) {
    var body =
    {
        country: '',
        state: '',
        city: city,
        name: '',
        address: '',
        radius: "20"
    };
    golflist = new XMLHttpRequest();
    golflist.onreadystatechange = function () {
        if (golflist.readyState == 4 && golflist.status == 200) {
            myobj = JSON.parse(golflist.responseText);
            for (list = 0; list < myobj.courses.length; list++) {
                $("#courseSelectionMenu").append("<option value = '" + myobj.courses[list].id + "'>" + myobj.courses[list].name + "</option> ");
            }
        }

    };
    golflist.open("POST", "http://golf-courses-api.herokuapp.com/courses/search", true);
    golflist.setRequestHeader("Content-Type", "application/json");
    golflist.send(JSON.stringify(body));
}
function selectCourse(id) {
    var extragolf = new XMLHttpRequest();
    extragolf.onreadystatechange = function () {
        if (extragolf.readyState == 4 && extragolf.status == 200) {
            golfCourse = JSON.parse(extragolf.responseText);
        }
    };
    extragolf.open("GET", "http://golf-courses-api.herokuapp.com/courses/" + id , true);
    extragolf.send();
    setTimeout(buildcard, 2000);
}
function endGame() {
    var score1 = document.getElementById('player1all').value;
    alert("Player one's score: " + score1);
    var score2 = document.getElementById('player2all').value;
    alert("Player two's score: " + score2);
    var score3 = document.getElementById('player3all').value;
    alert("Player three's score: " + score3);
    var score4 = document.getElementById('player4all').value;
    alert("Player four's score: " + score4);
    var score5 = document.getElementById('player5all').value;
    alert("Player five's score: " + score5);
    var score6 = document.getElementById('player6all').value;
    alert("Player six's score: " + score6);
}